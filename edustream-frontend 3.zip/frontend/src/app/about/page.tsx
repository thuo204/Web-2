import type { Metadata } from 'next';
import Link from 'next/link';
import { BookOpen, Users, Award, Globe, Heart, Target } from 'lucide-react';

export const metadata: Metadata = {
  title: 'About Us',
  description: 'Learn about EduStream\'s mission to democratize education worldwide.',
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      {/* Hero */}
      <div className="bg-gradient-to-br from-slate-900 via-primary-900 to-primary-800 text-white py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-1.5 text-sm text-white/90 mb-6">
            <Heart className="w-4 h-4 text-red-400" /> Our Story
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold mb-6 leading-tight">
            Empowering learners{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent-400 to-primary-300">
              worldwide
            </span>
          </h1>
          <p className="text-xl text-white/70 leading-relaxed max-w-2xl mx-auto">
            EduStream was founded with a simple belief: quality education should be accessible to everyone, everywhere.
          </p>
        </div>
      </div>

      {/* Mission */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          <div>
            <p className="text-primary-600 font-medium text-sm uppercase tracking-wide mb-3">Our Mission</p>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Making world-class education accessible</h2>
            <p className="text-gray-600 leading-relaxed mb-6">
              We believe that learning is the most powerful tool for changing lives. Our platform connects passionate instructors with curious students from 150+ countries.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Since our founding, we've helped over 50,000 students acquire new skills, advance their careers, and pursue their passions through high-quality, affordable online courses.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-5">
            {[
              { icon: BookOpen, value: '500+', label: 'Expert Courses', color: 'bg-blue-50 text-blue-600' },
              { icon: Users, value: '50K+', label: 'Active Students', color: 'bg-teal-50 text-teal-600' },
              { icon: Award, value: '200+', label: 'Instructors', color: 'bg-amber-50 text-amber-600' },
              { icon: Globe, value: '150+', label: 'Countries', color: 'bg-violet-50 text-violet-600' },
            ].map(({ icon: Icon, value, label, color }) => (
              <div key={label} className={`rounded-2xl p-6 ${color}`}>
                <Icon className="w-8 h-8 mb-3" />
                <div className="text-3xl font-bold mb-1">{value}</div>
                <div className="text-sm font-medium opacity-80">{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Values */}
        <div className="text-center mb-12">
          <p className="text-primary-600 font-medium text-sm uppercase tracking-wide mb-2">Our Values</p>
          <h2 className="text-3xl font-bold text-gray-900">What drives us</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {[
            { icon: Target, title: 'Excellence', desc: 'We curate only the highest quality courses from expert instructors with real-world experience.' },
            { icon: Heart, title: 'Accessibility', desc: 'We believe everyone deserves access to quality education, regardless of background or location.' },
            { icon: Globe, title: 'Community', desc: 'Learning is better together. We foster a supportive global community of curious minds.' },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="bg-white rounded-2xl border border-gray-100 p-8 text-center shadow-sm">
              <div className="w-14 h-14 bg-primary-50 rounded-2xl flex items-center justify-center mx-auto mb-5">
                <Icon className="w-7 h-7 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
              <p className="text-gray-600 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="bg-gradient-to-br from-primary-600 to-primary-800 rounded-3xl p-12 text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to start learning?</h2>
          <p className="text-primary-200 mb-8 text-lg">Join thousands of learners already on EduStream</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/courses" className="bg-white text-primary-600 font-semibold px-8 py-3 rounded-xl hover:bg-gray-100 transition-colors">
              Browse Courses
            </Link>
            <Link href="/auth/register" className="bg-primary-500 text-white font-semibold px-8 py-3 rounded-xl hover:bg-primary-400 transition-colors border border-primary-400">
              Get Started Free
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
