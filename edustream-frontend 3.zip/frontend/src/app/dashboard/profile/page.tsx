'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ChevronLeft, User, Lock, Camera, CheckCircle } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { authApi, userApi } from '@/lib/api';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const { isAuthenticated, user, updateUser } = useAuthStore();
  const router = useRouter();
  const [tab, setTab] = useState<'profile' | 'password'>('profile');
  const [profileForm, setProfileForm] = useState({ full_name: '', username: '', bio: '' });
  const [passwordForm, setPasswordForm] = useState({ current_password: '', new_password: '', confirm_password: '' });
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) router.push('/auth/login?redirect=/dashboard/profile');
    if (user) {
      setProfileForm({
        full_name: user.full_name || '',
        username: user.username || '',
        bio: (user as any).bio || '',
      });
    }
  }, [isAuthenticated, user]);

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await userApi.updateProfile(profileForm);
      updateUser(res.data.data);
      setSaved(true);
      toast.success('Profile updated successfully!');
      setTimeout(() => setSaved(false), 3000);
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordForm.new_password !== passwordForm.confirm_password) {
      toast.error('Passwords do not match');
      return;
    }
    if (passwordForm.new_password.length < 8) {
      toast.error('Password must be at least 8 characters');
      return;
    }
    setLoading(true);
    try {
      await authApi.changePassword({
        current_password: passwordForm.current_password,
        new_password: passwordForm.new_password,
      });
      toast.success('Password changed successfully!');
      setPasswordForm({ current_password: '', new_password: '', confirm_password: '' });
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to change password');
    } finally {
      setLoading(false);
    }
  };

  if (!isAuthenticated) return null;

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard" className="p-2 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Profile Settings</h1>
        </div>

        {/* Avatar section */}
        <div className="bg-white rounded-xl border border-gray-100 p-6 mb-6 shadow-sm">
          <div className="flex items-center gap-6">
            <div className="relative">
              {user?.avatar_url ? (
                <img src={user.avatar_url} alt={user.full_name} className="w-20 h-20 rounded-full object-cover" />
              ) : (
                <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center">
                  <span className="text-3xl font-bold text-primary-600">{user?.full_name?.charAt(0)}</span>
                </div>
              )}
              <button className="absolute bottom-0 right-0 w-7 h-7 bg-primary-600 text-white rounded-full flex items-center justify-center hover:bg-primary-700 transition-colors">
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 text-lg">{user?.full_name}</h3>
              <p className="text-gray-500 text-sm">@{user?.username}</p>
              <span className={`inline-flex items-center mt-1 text-xs px-2 py-0.5 rounded-full font-medium ${
                user?.role === 'admin' ? 'bg-red-100 text-red-700' :
                user?.role === 'instructor' ? 'bg-blue-100 text-blue-700' :
                'bg-gray-100 text-gray-600'
              }`}>
                {user?.role}
              </span>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setTab('profile')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              tab === 'profile' ? 'bg-primary-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}
          >
            <User className="w-4 h-4" /> Profile
          </button>
          <button
            onClick={() => setTab('password')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              tab === 'password' ? 'bg-primary-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Lock className="w-4 h-4" /> Password
          </button>
        </div>

        {tab === 'profile' && (
          <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
            <form onSubmit={handleProfileSubmit} className="space-y-5">
              <div>
                <label className="label">Full Name</label>
                <input
                  type="text"
                  value={profileForm.full_name}
                  onChange={(e) => setProfileForm(f => ({ ...f, full_name: e.target.value }))}
                  className="input"
                  required
                  minLength={2}
                />
              </div>
              <div>
                <label className="label">Username</label>
                <input
                  type="text"
                  value={profileForm.username}
                  onChange={(e) => setProfileForm(f => ({ ...f, username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') }))}
                  className="input"
                  required
                  minLength={3}
                  maxLength={30}
                />
              </div>
              <div>
                <label className="label">Bio</label>
                <textarea
                  value={profileForm.bio}
                  onChange={(e) => setProfileForm(f => ({ ...f, bio: e.target.value }))}
                  className="input h-24 resize-none"
                  placeholder="Tell us about yourself..."
                  maxLength={500}
                />
                <p className="text-xs text-gray-400 mt-1">{profileForm.bio.length}/500</p>
              </div>
              <div className="flex items-center gap-3">
                <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2">
                  {loading ? 'Saving...' : 'Save Changes'}
                </button>
                {saved && (
                  <span className="flex items-center gap-1 text-sm text-accent-600">
                    <CheckCircle className="w-4 h-4" /> Saved!
                  </span>
                )}
              </div>
            </form>
          </div>
        )}

        {tab === 'password' && (
          <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
            <form onSubmit={handlePasswordSubmit} className="space-y-5">
              <div>
                <label className="label">Current Password</label>
                <input
                  type="password"
                  value={passwordForm.current_password}
                  onChange={(e) => setPasswordForm(f => ({ ...f, current_password: e.target.value }))}
                  className="input"
                  required
                />
              </div>
              <div>
                <label className="label">New Password</label>
                <input
                  type="password"
                  value={passwordForm.new_password}
                  onChange={(e) => setPasswordForm(f => ({ ...f, new_password: e.target.value }))}
                  className="input"
                  required
                  minLength={8}
                />
              </div>
              <div>
                <label className="label">Confirm New Password</label>
                <input
                  type="password"
                  value={passwordForm.confirm_password}
                  onChange={(e) => setPasswordForm(f => ({ ...f, confirm_password: e.target.value }))}
                  className="input"
                  required
                />
              </div>
              <button type="submit" disabled={loading} className="btn-primary">
                {loading ? 'Changing...' : 'Change Password'}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
