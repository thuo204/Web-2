import type { Metadata } from 'next';
import { HeroSection } from '@/components/layout/HeroSection';
import { FeaturedCourses } from '@/components/course/FeaturedCourses';
import { FeaturedArticles } from '@/components/blog/FeaturedArticles';
import { StatsSection } from '@/components/layout/StatsSection';
import { CategoryGrid } from '@/components/layout/CategoryGrid';

export const metadata: Metadata = {
  title: 'EduStream - Learn, Grow, Succeed',
  description: 'Access 500+ expert-led courses, insightful articles, and join 50,000+ learners worldwide.',
};

export default async function HomePage() {
  return (
    <div>
      <HeroSection />
      <StatsSection />
      <CategoryGrid />
      <FeaturedCourses />
      <FeaturedArticles />
    </div>
  );
}
