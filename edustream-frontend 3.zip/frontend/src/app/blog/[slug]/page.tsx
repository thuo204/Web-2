import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Calendar, Clock, Eye, Tag, ArrowLeft } from 'lucide-react';
import { CommentSection } from '@/components/blog/CommentSection';

async function getArticle(slug: string) {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/articles/${slug}`, {
      next: { revalidate: 300 }
    });
    if (!res.ok) return null;
    return (await res.json()).data;
  } catch { return null; }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const article = await getArticle(params.slug);
  if (!article) return {};
  return {
    title: article.seo_title || article.title,
    description: article.seo_description || article.excerpt,
    openGraph: {
      title: article.title,
      description: article.excerpt,
      images: [{ url: article.cover_image_url || '/og-default.png', width: 1200, height: 630 }],
      type: 'article',
      publishedTime: article.published_at,
      authors: [article.author_name],
    },
  };
}

export default async function ArticlePage({ params }: { params: { slug: string } }) {
  const article = await getArticle(params.slug);
  if (!article) notFound();

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: article.title,
    description: article.excerpt,
    image: article.cover_image_url,
    author: { '@type': 'Person', name: article.author_name },
    publisher: { '@type': 'Organization', name: 'EduStream' },
    datePublished: article.published_at,
    dateModified: article.updated_at,
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />

      <div className="min-h-screen bg-[#F8FAFC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid lg:grid-cols-4 gap-10">
            <article className="lg:col-span-3">
              <Link href="/blog" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-primary-600 mb-6 transition-colors">
                <ArrowLeft className="w-4 h-4" /> Back to Blog
              </Link>

              <div className="flex flex-wrap gap-2 mb-5">
                {article.category_name && (
                  <Link href={`/blog?category=${article.category_slug}`} className="badge bg-primary-100 text-primary-700 hover:bg-primary-200 transition-colors">
                    {article.category_name}
                  </Link>
                )}
                {article.tags?.map((tag: any) => (
                  <Link key={tag.slug} href={`/blog?tag=${tag.slug}`} className="badge bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors">
                    <Tag className="w-3 h-3 mr-1" />{tag.name}
                  </Link>
                ))}
              </div>

              <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 leading-tight mb-6">{article.title}</h1>

              <div className="flex flex-wrap items-center gap-5 text-sm text-gray-500 mb-8 pb-6 border-b border-gray-200">
                <span className="flex items-center gap-2">
                  {article.author_avatar ? (
                    <img src={article.author_avatar} alt={article.author_name} className="w-8 h-8 rounded-full object-cover" />
                  ) : (
                    <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                      <span className="text-primary-700 text-xs font-bold">{article.author_name?.charAt(0)}</span>
                    </div>
                  )}
                  <span className="font-medium text-gray-700">{article.author_name}</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-4 h-4" />
                  {new Date(article.published_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4" />
                  {article.read_time} min read
                </span>
                <span className="flex items-center gap-1.5">
                  <Eye className="w-4 h-4" />
                  {(article.view_count || 0).toLocaleString()} views
                </span>
              </div>

              {article.cover_image_url && (
                <div className="rounded-2xl overflow-hidden mb-8 shadow-sm">
                  <img src={article.cover_image_url} alt={article.title} className="w-full aspect-video object-cover" />
                </div>
              )}

              {article.excerpt && (
                <p className="text-xl text-gray-600 leading-relaxed mb-8 font-medium border-l-4 border-primary-300 pl-5 py-2 bg-primary-50 rounded-r-lg">
                  {article.excerpt}
                </p>
              )}

              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: article.content }} />

              {article.author_bio && (
                <div className="mt-10 bg-white rounded-xl border border-gray-200 p-6 flex gap-5">
                  {article.author_avatar ? (
                    <img src={article.author_avatar} alt={article.author_name} className="w-16 h-16 rounded-full object-cover shrink-0" />
                  ) : (
                    <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center shrink-0">
                      <span className="text-primary-700 text-xl font-bold">{article.author_name?.charAt(0)}</span>
                    </div>
                  )}
                  <div>
                    <p className="text-xs text-gray-400 mb-1 uppercase tracking-wide">About the Author</p>
                    <h3 className="font-bold text-gray-900 mb-2">{article.author_name}</h3>
                    <p className="text-sm text-gray-600 leading-relaxed">{article.author_bio}</p>
                  </div>
                </div>
              )}

              {article.related_articles?.length > 0 && (
                <div className="mt-12">
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Related Articles</h2>
                  <div className="grid sm:grid-cols-2 gap-5">
                    {article.related_articles.map((related: any) => (
                      <Link key={related.id} href={`/blog/${related.slug}`} className="card group flex gap-4 p-4 overflow-hidden">
                        {related.cover_image_url && (
                          <img src={related.cover_image_url} alt={related.title} className="w-20 h-16 object-cover rounded-lg shrink-0" />
                        )}
                        <div className="min-w-0">
                          <h4 className="text-sm font-semibold text-gray-900 group-hover:text-primary-600 transition-colors line-clamp-2">
                            {related.title}
                          </h4>
                          <p className="text-xs text-gray-400 mt-1">{related.read_time} min read</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-12">
                <CommentSection articleId={article.id} commentCount={article.comment_count || 0} />
              </div>
            </article>

            <aside className="space-y-6">
              <div className="sticky top-24 space-y-6">
                <div className="bg-white rounded-xl border border-gray-100 p-5">
                  <h3 className="font-bold text-gray-900 mb-4">Quick Navigation</h3>
                  <p className="text-sm text-gray-500">Use the breadcrumb to explore more articles in the same category.</p>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </>
  );
}
